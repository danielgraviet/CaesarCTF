# box2file.py

import hashlib

def check_password(user_input):
    correct_hash = hashlib.md5("SecretPass456".encode()).hexdigest()
    input_hash = hashlib.md5(user_input.strip().encode()).hexdigest()
    
    if input_hash == correct_hash:
        directions = """
        Success! Decryption instructions for box3:
        1. Locate encrypted file in box3
        2. Apply Caesar cipher decryption
        3. Shift: 3 positions back (e.g., D -> A)
        4. Look for: itc101
        """
        return directions
    else:
        return "Wrong password hash! Access denied."

if __name__ == "__main__":
    print("Hint: The password came from box1")
    user_input = input("Enter password: ")
    print(check_password(user_input))